## The three-file explanation

**HTML creates the elements. CSS controls their appearance. JavaScript changes them after the page loads.**

`index.html` loads `styles.css` through a `<link>` and `script.js` through a `<script defer>`. `defer` lets the browser finish reading the HTML before the script looks for its elements.

A **class** groups elements for styling, such as `.button`. An **ID** identifies a particular element, such as `#site-menu`. JavaScript's `querySelector` finds an element using those same selectors.

## How did you make the Explore button?

In HTML it is an `<a class="button primary" href="#skills">`. It is a link because its job is navigation. `#skills` points to the section whose ID is `skills`.

In CSS, `.button` adds padding, spacing, and a minimum height. `display: inline-flex` places its text and arrow beside each other. `.primary` gives it the cream background. `.button:hover` raises it 3 pixels, and `transition` makes that change gradual.

The browser handles the jump. `html { scroll-behavior: smooth; }` makes anchor navigation scroll smoothly, so this button needs no JavaScript click handler.

**To change it:** edit its text or `href` in HTML; edit `.button` or `.primary` in CSS.

## How do Don't Open and Don't hire me work?

They are `<button>` elements because they perform actions. JavaScript listens for a `click` and calls `showModal()` on the matching `<dialog>`.

Don't Open opens `#site-menu`. CSS places it against the right edge. JavaScript adds `menu-open` to the body to stop background scrolling and updates `aria-expanded` to announce that it is open.

Don't hire me opens `#cv-dialog`, which currently says the CV is coming soon. Its close and Got it buttons call `close()`. The menu closes through Close, its links, Escape, or a click outside the dialog.

`<dialog>` supplies the modal behavior and keyboard focus handling. `::backdrop` supplies the dimmed, blurred background. The menu looks like a side panel; it does not currently have an opening slide animation.

**To change it:** edit the dialog HTML, its CSS rules, or the dialog handlers near the bottom of JavaScript.

## How did you make the scroll animation?

There are two separate effects:

- **Portrait:** `updatePortrait()` changes the photo's CSS `transform` according to scroll distance. The headline stays still.
- **Section reveals:** an `IntersectionObserver` watches `.reveal` elements. When an element enters the screen, it adds `.visible`. CSS transitions change opacity from 0 to 1 and move it from 35 pixels down to its normal position.

`requestScrollUpdate()` groups rapid scroll events into one update per repaint. `clamp()` limits the testimonial progress to 0–1.

**To change it:** edit the distance multiplier in `updatePortrait()` or the `.reveal` transition duration.

## How do the client testimonials rotate?

HTML contains three cards and three numbered buttons. Each card has a name, a photo, a badge, and a quote.

CSS makes the section tall and its inner `.testimonial-stage` sticky. This holds the display on screen while the visitor scrolls through the section. Cards occupy the same space and `.testimonial-deck` supplies perspective for the rotation.

`updateTestimonials()` divides the distance scrolled into the section by its available sticky travel. It multiplies the resulting 0–1 progress by the last card index, which is 2 for three cards.

Each card's distance from that current index controls its `rotateY` angle and opacity. Distance 0 faces the viewer at full opacity. As the distance increases, that card turns away and fades out.

**Example:** section progress 0 selects Leon; 0.5 selects Kasper; 1 selects the dog. Between those positions, outgoing and incoming cards rotate and crossfade.

Clicking 01, 02, or 03 scrolls to the corresponding section position. `aria-current` identifies the selected button, while `aria-hidden` keeps inactive cards out of the screen-reader reading order.

Inside a card, CSS Grid gives the name, photo/badge row, and quote their own spaces. This prevents the photo from covering the quote. `object-fit: cover` fills the round photo frame without stretching the image.

**To change it:** edit card content in HTML, card spacing in CSS, or rotation and fade values in `updateTestimonials()`. Adding a card also requires adding its number button.

## How did you create the footer?

It is a `<footer id="contact">` with a large email link, a portrait, social links, and navigation. CSS Flexbox aligns the SAY, portrait, and HI pieces. `-webkit-text-stroke` outlines HI; `rotate()` tilts the portrait.

The social symbols are inline SVG shapes drawn with paths, circles, and rectangles. CSS sets their size and stroke color. Their surrounding `<a>` elements contain the actual profile addresses, so they do not need JavaScript.

`mailto:Bassam@lordsam.fi` asks the visitor's configured email app to compose an email. It does not send an email automatically. Social profile links use `target="_blank"` to open a new tab and `rel="noopener noreferrer"` for separation from the original page.

**To change it:** edit link addresses in HTML and the `.contact-footer`, `.say-hi`, `.social-rail`, and `.footer-bottom` rules in CSS.

## How does it adapt to phones and motion preferences?

The `max-width:800px` media query adjusts the same elements for smaller screens. It changes two columns into one, shrinks text/cards, hides header links, and moves the social icons into a row. The menu button remains available.

`clamp(minimum, flexible size, maximum)` allows heading sizes to grow with screen width within limits. `svh` and `dvh` are viewport-height units used for the hero, sticky stage, and menu.

The Pause motion button changes the JavaScript `paused` state. That stops portrait movement and removes card rotation; scrolling can still change the selected testimonial.

`matchMedia` checks the visitor's reduced-motion preference. Those visitors see all three testimonials in normal page order, with no portrait movement, rotation, or reveal transitions.

## What about the other files?

The four images are assets; their HTML `src` values determine where they appear. `README.md` explains running and editing the site. This guide is preparation material, not code loaded by the browser.

`.openai/hosting.json` stores the registered hosting project ID. It is configuration data, not a page script, and it does not publish the website automatically.

## A short answer when your teacher points at anything

Find its HTML element, its CSS selector, and any JavaScript handler. Explain: **what the element is, how it is styled, and what event changes it.** If it is a normal link or a hover effect, the browser or CSS handles it without JavaScript.
