# Lord Sam's portfolio

A static website built with HTML, CSS, and JavaScript. No framework, packages, or build step.

## Files to edit

- `dist/index.html` — page content, sections, photos, links, and buttons.
- `dist/styles.css` — colors, fonts, layout, hover effects, and responsive rules.
- `dist/script.js` — portrait scrolling, section reveals, testimonial rotation, and dialogs.
- `STUDY-GUIDE.md` — short answers to common presentation questions.

Each source file uses short comments above the feature it controls. CSS has one main set of rules per feature, followed by screen-size and reduced-motion adjustments.

## Open the website

Open `dist/index.html` in a browser. For a local web preview, run `python -m http.server 4173 --directory dist` from this folder and visit `http://localhost:4173`.

## Images and links

`portrait.png` is the hero and footer portrait. `client-leon.jpg`, `client-kasper.jpg`, and `client-dog.png` are the testimonial photos. They are inside `dist` beside the HTML.

The footer contains the supplied X, Instagram, LinkedIn, and email links. The CV dialog is a placeholder. Testimonials are a playful class-presentation example; their removal after class is manual.

The `.openai/hosting.json` file records the registered hosting project ID; it does not change the page or publish it automatically.
